'use client';

import { useEffect, useRef, useState } from 'react';

export type Guidance = 'waiting' | 'centre' | 'dark' | 'bright' | 'closer' | 'back' | 'good';

export const GUIDANCE: Record<Guidance, { text: string; tone: 'neutral' | 'warn' | 'good' }> = {
  waiting: { text: 'Fit your face inside the oval, then press Start capture.', tone: 'neutral' },
  centre: { text: 'Centre your face in the oval.', tone: 'warn' },
  dark: { text: 'Too dark. Face a light or move somewhere brighter.', tone: 'warn' },
  bright: { text: 'Too bright. Move away from direct light.', tone: 'warn' },
  closer: { text: 'Move closer to the camera.', tone: 'warn' },
  back: { text: 'Move back a little.', tone: 'warn' },
  good: { text: 'Good. Hold still.', tone: 'good' },
};

// Each sample shows these hints first, so all five messages can be seen in a demo.
const PLAN: Guidance[][] = [['centre'], ['dark'], ['closer'], ['bright', 'back'], ['centre']];

/**
 * FAKE face detection. Replace this hook with a real detector that reads the
 * video frames and reports lighting, distance and position.
 */
export function useCaptureSimulator({ running, total, onDone }: { running: boolean; total: number; onDone: () => void }) {
  const [guidance, setGuidance] = useState<Guidance>('waiting');
  const [count, setCount] = useState(0);
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    if (!running) {
      setGuidance('waiting');
      return;
    }
    let cancelled = false;
    setCount(0);
    const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
    (async () => {
      for (let i = 0; i < total; i++) {
        for (const hint of PLAN[i % PLAN.length]) {
          if (cancelled) return;
          setGuidance(hint);
          await wait(1200);
        }
        if (cancelled) return;
        setGuidance('good');
        await wait(1300);
        if (cancelled) return;
        setCount(i + 1);
      }
      if (!cancelled) doneRef.current();
    })();
    return () => {
      cancelled = true;
    };
  }, [running, total]);

  return { guidance, count };
}
