/**
 * ClassCheck data layer (MOCK).
 *
 * Every page talks to the backend only through this module. To go live, keep the
 * exported function names and types, and replace each body with a fetch() call.
 * Nothing under /app or /components should need to change.
 *
 * Mock behaviour:
 *  - State lives in localStorage so a reload keeps accounts, sessions and check-ins.
 *  - Demo accounts (password "classcheck"): student@, instructor@ and admin@classcheck.test
 *  - To force a check-in outcome while demoing, run in the browser console:
 *      localStorage.setItem('classcheck.mock.outcome', 'APPROVED' | 'REVIEW' | 'REJECTED')
 *    and remove the key to go back to random outcomes.
 *  - Do not store passwords like this in a real system. This is a demo only.
 */
import { LAYER_KEYS } from './layers';
import type {
  CheckIn,
  ClassSession,
  CodeToken,
  Coords,
  Decision,
  DecisionFilter,
  Enrollment,
  LayerKey,
  Layers,
  Role,
  User,
} from './types';

/* ------------------------------------------------------------------ errors */

export class ApiError extends Error {
  /** What to do next, in plain language. */
  fix: string;
  constructor(message: string, fix: string) {
    super(message);
    this.name = 'ApiError';
    this.fix = fix;
  }
}

export function toErrorInfo(e: unknown): { message: string; fix: string } {
  if (e instanceof ApiError) return { message: e.message, fix: e.fix };
  return {
    message: 'Something went wrong.',
    fix: 'Check your connection and try again. If it keeps happening, contact your administrator.',
  };
}

/* ----------------------------------------------------------------- storage */

const KEY = {
  db: 'classcheck.mock.db.v1',
  session: 'classcheck.mock.session',
  device: 'classcheck.deviceId',
  force: 'classcheck.mock.outcome',
};
const WINDOW_MS = 30_000;
const DEMO_PASSWORD = 'classcheck';

interface StoredUser extends User {
  password: string;
}
interface StoredEnrollment {
  consentAt: string | null;
  deviceId: string | null;
  deviceLabel: string | null;
  faceEnrolledAt: string | null;
}
interface Db {
  users: StoredUser[];
  enrollments: Record<string, StoredEnrollment>;
  sessions: ClassSession[];
  checkIns: CheckIn[];
  lastSimAt: number;
}

const delay = (ms = 350) => new Promise<void>((r) => setTimeout(r, ms + Math.random() * 200));
const uid = () => Math.random().toString(36).slice(2, 8);
const iso = (ms: number) => new Date(ms).toISOString();

function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function loadDb(): Db {
  const raw = window.localStorage.getItem(KEY.db);
  if (raw) {
    try {
      return JSON.parse(raw) as Db;
    } catch {
      /* fall through and reseed */
    }
  }
  const db = seed();
  saveDb(db);
  return db;
}
function saveDb(db: Db) {
  window.localStorage.setItem(KEY.db, JSON.stringify(db));
}

/* -------------------------------------------------------------- mock engine */

const FAIL_NOTES: Record<LayerKey, string> = {
  face: 'Your face did not match your enrolled template. Try again in even light with your whole face inside the oval, or re-enrol if your appearance has changed.',
  liveness: 'We could not confirm a live person. Look straight at the camera and blink twice, slowly.',
  location: 'You were outside the classroom radius. Move into the classroom and check that Location is on for this site.',
  device: 'This is not the device registered to your account. Use your registered phone, or register this one on the Enrol page.',
  code: 'The class code was not accepted. Scan the QR code on the instructor screen again.',
  behaviour: 'The check-in pattern looked unusual, so a person will review it. You do not need to do anything.',
};

const ROSTER = [
  { name: 'Isha Patel', no: 'EN2021002' },
  { name: 'Rohan Desai', no: 'EN2021011' },
  { name: 'Kavya Nair', no: 'EN2021018' },
  { name: 'Dev Shah', no: 'EN2021023' },
  { name: 'Sana Qureshi', no: 'EN2021031' },
  { name: 'Vikram Joshi', no: 'EN2021037' },
  { name: 'Neha Trivedi', no: 'EN2021052' },
  { name: 'Arjun Rao', no: 'EN2021058' },
  { name: 'Tanvi Mehta', no: 'EN2021064' },
  { name: 'Yash Parikh', no: 'EN2021071' },
];

function buildLayers(fails: Partial<Record<LayerKey, string>>, rnd: () => number): Layers {
  const out = {} as Layers;
  for (const k of LAYER_KEYS) {
    const note = fails[k] ?? null;
    out[k] = note
      ? { passed: false, score: Math.round(18 + rnd() * 44), note }
      : { passed: true, score: Math.round(82 + rnd() * 17), note: null };
  }
  return out;
}

function summarise(layers: Layers): { decision: Decision; confidence: number } {
  const failed = LAYER_KEYS.filter((k) => !layers[k].passed);
  const confidence = Math.round(LAYER_KEYS.reduce((n, k) => n + layers[k].score, 0) / LAYER_KEYS.length);
  if (failed.length === 0) return { decision: 'APPROVED', confidence };
  const hard = failed.some((k) => k === 'face' || k === 'liveness' || k === 'code');
  if (hard || failed.length >= 2) return { decision: 'REJECTED', confidence };
  return { decision: 'REVIEW', confidence };
}

function buildReason(decision: Decision, layers: Layers, title: string): string {
  if (decision === 'APPROVED') return `All six checks passed. Your attendance for ${title} is recorded.`;
  const notes = LAYER_KEYS.filter((k) => !layers[k].passed).map((k) => layers[k].note);
  const lead =
    decision === 'REVIEW'
      ? 'Your check-in needs a quick look from your instructor.'
      : 'Your check-in was not accepted.';
  return `${lead} ${notes.join(' ')}`;
}

function pick<T>(rnd: () => number, a: T[]): T {
  return a[Math.floor(rnd() * a.length)];
}

function randomFails(plan: Decision, rnd: () => number): Partial<Record<LayerKey, string>> {
  const f: Partial<Record<LayerKey, string>> = {};
  if (plan === 'REVIEW') {
    const k = pick<LayerKey>(rnd, ['behaviour', 'location', 'device']);
    f[k] = FAIL_NOTES[k];
  }
  if (plan === 'REJECTED') {
    const k = pick<LayerKey>(rnd, ['face', 'liveness', 'code']);
    f[k] = FAIL_NOTES[k];
    if (rnd() < 0.5) f.behaviour = FAIL_NOTES.behaviour;
  }
  return f;
}

function weightedPlan(rnd: () => number): Decision {
  const r = rnd();
  return r < 0.7 ? 'APPROVED' : r < 0.88 ? 'REVIEW' : 'REJECTED';
}

function readForced(): Decision | null {
  const v = window.localStorage.getItem(KEY.force);
  return v === 'APPROVED' || v === 'REVIEW' || v === 'REJECTED' ? v : null;
}

function makeCheckIn(p: {
  session: Pick<ClassSession, 'id' | 'title'>;
  studentId: string;
  name: string;
  enrolmentNo: string;
  at: number;
  fails: Partial<Record<LayerKey, string>>;
  rnd: () => number;
  tweak?: (l: Layers) => void;
}): CheckIn {
  const layers = buildLayers(p.fails, p.rnd);
  p.tweak?.(layers);
  const { decision, confidence } = summarise(layers);
  return {
    id: `c_${uid()}${uid()}`,
    sessionId: p.session.id,
    sessionTitle: p.session.title,
    studentId: p.studentId,
    studentName: p.name,
    enrolmentNo: p.enrolmentNo,
    at: iso(p.at),
    decision,
    confidence,
    layers,
    reason: buildReason(decision, layers, p.session.title),
    resolvedBy: null,
  };
}

function seed(): Db {
  const now = Date.now();
  const rnd = mulberry32(42);
  const users: StoredUser[] = [
    { id: 'u_student', fullName: 'Aarav Mehta', enrolmentNo: 'EN2021045', email: 'student@classcheck.test', role: 'student', password: DEMO_PASSWORD },
    { id: 'u_instructor', fullName: 'Dr. Meera Shah', enrolmentNo: 'STAFF-114', email: 'instructor@classcheck.test', role: 'instructor', password: DEMO_PASSWORD },
    { id: 'u_admin', fullName: 'Admin Office', enrolmentNo: 'STAFF-001', email: 'admin@classcheck.test', role: 'admin', password: DEMO_PASSWORD },
  ];
  const sessions: ClassSession[] = [
    { id: 'SEED01', title: 'Data Structures, Lecture 12', radiusM: 100, durationMin: 60, lat: 21.1702, lng: 72.8311, startedAt: iso(now - 26 * 3600e3), endsAt: iso(now - 25 * 3600e3), instructorId: 'u_instructor', status: 'closed' },
    { id: 'SEED02', title: 'Operating Systems, Lab 4', radiusM: 80, durationMin: 60, lat: 21.1702, lng: 72.8311, startedAt: iso(now - 3 * 3600e3), endsAt: iso(now - 2 * 3600e3), instructorId: 'u_instructor', status: 'closed' },
  ];
  const checkIns: CheckIn[] = [];
  let n = 0;
  for (const s of sessions) {
    const base = Date.parse(s.startedAt);
    ROSTER.forEach((st, i) => {
      n += 1;
      const plan: Decision = n % 6 === 2 ? 'REVIEW' : n % 9 === 5 ? 'REJECTED' : 'APPROVED';
      checkIns.push(
        makeCheckIn({
          session: s,
          studentId: `r_${st.no}`,
          name: st.name,
          enrolmentNo: st.no,
          at: base + (i + 1) * 95_000 + Math.floor(rnd() * 40_000),
          fails: randomFails(plan, rnd),
          rnd,
        }),
      );
    });
  }
  return { users, enrollments: {}, sessions, checkIns, lastSimAt: 0 };
}

/** Adds a simulated arrival to the open session so live feeds have something to show. */
function maybeSimulate(db: Db): boolean {
  const open = db.sessions.find((s) => s.status === 'open' && Date.parse(s.endsAt) > Date.now());
  if (!open || Date.now() - db.lastSimAt < 9000) return false;
  const taken = new Set(db.checkIns.filter((c) => c.sessionId === open.id).map((c) => c.enrolmentNo));
  const free = ROSTER.filter((r) => !taken.has(r.no));
  if (free.length === 0) return false;
  const st = pick(Math.random, free);
  db.checkIns.push(
    makeCheckIn({
      session: open,
      studentId: `r_${st.no}`,
      name: st.name,
      enrolmentNo: st.no,
      at: Date.now(),
      fails: randomFails(weightedPlan(Math.random), Math.random),
      rnd: Math.random,
    }),
  );
  db.lastSimAt = Date.now();
  return true;
}

/* -------------------------------------------------------------- QR codes */

function codeSig(sessionId: string, w: number): string {
  let h = 2166136261;
  const s = `${sessionId}:${w}:classcheck`;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(36).toUpperCase().padStart(6, '0').slice(0, 6);
}
function makeCode(sessionId: string, w: number): string {
  return `CC1-${sessionId}-${w}-${codeSig(sessionId, w)}`;
}
function parseCode(code: string): { sessionId: string; window: number; sig: string } | null {
  const parts = code.trim().split('-');
  if (parts.length !== 4 || parts[0] !== 'CC1') return null;
  const w = Number(parts[2]);
  if (!Number.isInteger(w)) return null;
  return { sessionId: parts[1], window: w, sig: parts[3] };
}

function distanceM(a: Coords, b: { lat: number; lng: number }): number {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/* ------------------------------------------------------------------- device */

export function getDeviceId(): string {
  let id = window.localStorage.getItem(KEY.device);
  if (!id) {
    id =
      typeof crypto !== 'undefined' && 'randomUUID' in crypto
        ? crypto.randomUUID()
        : `dev-${uid()}${uid()}${uid()}`;
    window.localStorage.setItem(KEY.device, id);
  }
  return id;
}

function describeDevice(): string {
  const ua = navigator.userAgent;
  const os = /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Windows/.test(ua) ? 'Windows' : /Mac/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : 'an unknown system';
  const br = /Edg\//.test(ua) ? 'Edge' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  return `${br} on ${os}`;
}

/* --------------------------------------------------------------------- auth */

const publicUser = ({ password: _p, ...u }: StoredUser): User => u;

function requireUser(role?: Role): User {
  const raw = window.localStorage.getItem(KEY.session);
  const db = loadDb();
  const u = raw ? db.users.find((x) => x.id === raw) : undefined;
  if (!u) throw new ApiError('You are signed out.', 'Sign in again to continue.');
  if (role && u.role !== role) throw new ApiError('Your account cannot do this.', `Sign in with a ${role} account.`);
  return publicUser(u);
}

export async function getCurrentUser(): Promise<User | null> {
  await delay(120);
  const id = window.localStorage.getItem(KEY.session);
  if (!id) return null;
  const u = loadDb().users.find((x) => x.id === id);
  return u ? publicUser(u) : null;
}

export async function login(email: string, password: string): Promise<User> {
  await delay();
  const u = loadDb().users.find((x) => x.email.toLowerCase() === email.trim().toLowerCase());
  if (!u || u.password !== password) {
    throw new ApiError('The email or password is wrong.', 'Check both and try again. Passwords are case-sensitive.');
  }
  window.localStorage.setItem(KEY.session, u.id);
  return publicUser(u);
}

export async function register(input: { fullName: string; enrolmentNo: string; email: string; password: string }): Promise<User> {
  await delay(500);
  const db = loadDb();
  if (db.users.some((x) => x.email.toLowerCase() === input.email.trim().toLowerCase())) {
    throw new ApiError('An account with this email already exists.', 'Sign in instead, or use a different email.');
  }
  if (db.users.some((x) => x.enrolmentNo.toLowerCase() === input.enrolmentNo.trim().toLowerCase())) {
    throw new ApiError('This enrolment number is already registered.', 'Sign in instead. If it is not yours, contact your administrator.');
  }
  const u: StoredUser = {
    id: `u_${uid()}${uid()}`,
    fullName: input.fullName.trim(),
    enrolmentNo: input.enrolmentNo.trim().toUpperCase(),
    email: input.email.trim(),
    role: 'student',
    password: input.password,
  };
  db.users.push(u);
  saveDb(db);
  window.localStorage.setItem(KEY.session, u.id);
  return publicUser(u);
}

export async function logout(): Promise<void> {
  window.localStorage.removeItem(KEY.session);
}

/* --------------------------------------------------------------- enrolment */

function toEnrollment(e: StoredEnrollment | undefined): Enrollment {
  return {
    consentAt: e?.consentAt ?? null,
    faceEnrolled: !!e?.faceEnrolledAt,
    faceEnrolledAt: e?.faceEnrolledAt ?? null,
    deviceRegistered: !!e?.deviceId,
    thisDeviceBound: !!e?.deviceId && e.deviceId === getDeviceId(),
    deviceLabel: e?.deviceLabel ?? null,
  };
}

function mutateEnrollment(fn: (e: StoredEnrollment) => void): Enrollment {
  const u = requireUser('student');
  const db = loadDb();
  const e = db.enrollments[u.id] ?? { consentAt: null, deviceId: null, deviceLabel: null, faceEnrolledAt: null };
  fn(e);
  db.enrollments[u.id] = e;
  saveDb(db);
  return toEnrollment(e);
}

export async function getEnrollment(): Promise<Enrollment> {
  await delay();
  const u = requireUser('student');
  return toEnrollment(loadDb().enrollments[u.id]);
}

export async function giveConsent(): Promise<Enrollment> {
  await delay();
  return mutateEnrollment((e) => {
    e.consentAt = iso(Date.now());
  });
}

export async function registerDevice(): Promise<Enrollment> {
  await delay(600);
  return mutateEnrollment((e) => {
    e.deviceId = getDeviceId();
    e.deviceLabel = describeDevice();
  });
}

/**
 * Sends face templates (numeric vectors, never images). For now the UI sends
 * placeholder vectors; swap in real embeddings from your face model later.
 */
export async function submitFaceTemplates(templates: number[][]): Promise<Enrollment> {
  await delay(900);
  const u = requireUser('student');
  if (!loadDb().enrollments[u.id]?.consentAt) {
    throw new ApiError('Consent has not been saved.', 'Tick the consent box and save it, then capture your face again.');
  }
  if (templates.length < 5) {
    throw new ApiError('Not enough face samples.', 'Capture all 5 samples and try again.');
  }
  return mutateEnrollment((e) => {
    e.faceEnrolledAt = iso(Date.now());
  });
}

export async function withdrawConsentAndDeleteFaceData(): Promise<Enrollment> {
  await delay(700);
  return mutateEnrollment((e) => {
    e.consentAt = null;
    e.faceEnrolledAt = null;
  });
}

/* ---------------------------------------------------------------- sessions */

export interface StartSessionInput {
  title: string;
  radiusM: number;
  durationMin: number;
  coords: Coords;
}

export async function getActiveSession(): Promise<ClassSession | null> {
  await delay();
  const u = requireUser('instructor');
  const s = loadDb().sessions.find((x) => x.instructorId === u.id && x.status === 'open' && Date.parse(x.endsAt) > Date.now());
  return s ?? null;
}

export async function startSession(input: StartSessionInput): Promise<ClassSession> {
  await delay(600);
  const u = requireUser('instructor');
  const db = loadDb();
  db.sessions.forEach((s) => {
    if (s.instructorId === u.id && s.status === 'open') s.status = 'closed';
  });
  const now = Date.now();
  const session: ClassSession = {
    id: `S${uid().toUpperCase()}`,
    title: input.title.trim(),
    radiusM: input.radiusM,
    durationMin: input.durationMin,
    lat: input.coords.lat,
    lng: input.coords.lng,
    startedAt: iso(now),
    endsAt: iso(now + input.durationMin * 60_000),
    instructorId: u.id,
    status: 'open',
  };
  db.sessions.push(session);
  saveDb(db);
  return session;
}

export async function endSession(sessionId: string): Promise<void> {
  await delay();
  requireUser('instructor');
  const db = loadDb();
  const s = db.sessions.find((x) => x.id === sessionId);
  if (s) s.status = 'closed';
  saveDb(db);
}

/** Returns the QR payload for the current 30-second window. */
export async function getSessionCode(sessionId: string): Promise<CodeToken> {
  await delay(80);
  requireUser('instructor');
  const s = loadDb().sessions.find((x) => x.id === sessionId);
  if (!s || s.status !== 'open' || Date.parse(s.endsAt) < Date.now()) {
    throw new ApiError('This session has ended.', 'Start a new session to show a new QR code.');
  }
  const w = Math.floor(Date.now() / WINDOW_MS);
  return { code: makeCode(sessionId, w), issuedAt: w * WINDOW_MS, expiresAt: (w + 1) * WINDOW_MS };
}

/* ---------------------------------------------------------------- check-in */

export interface CheckInInput {
  code: string;
  challenge: 'blink' | 'turn';
  coords: Coords | null;
  geoError?: string;
  deviceId: string;
  behaviour: { elapsedMs: number; method: 'scan' | 'paste'; livenessMs: number };
}

export async function submitCheckIn(input: CheckInInput): Promise<CheckIn> {
  await delay(1300);
  const user = requireUser('student');
  const db = loadDb();

  const parsed = parseCode(input.code);
  if (!parsed) {
    throw new ApiError('That is not a ClassCheck code.', 'Scan the QR code on the instructor screen again, or paste the full code shown under it.');
  }
  const session = db.sessions.find((s) => s.id === parsed.sessionId);
  if (!session || session.status !== 'open' || Date.parse(session.endsAt) < Date.now()) {
    throw new ApiError('This class session is not open.', 'Ask your instructor to start a session, then scan the new QR code.');
  }
  if (codeSig(parsed.sessionId, parsed.window) !== parsed.sig) {
    throw new ApiError('That code is not valid.', 'Scan the QR code on the instructor screen again.');
  }

  const rnd = Math.random;
  const fails = randomFails(readForced() ?? weightedPlan(rnd), rnd);

  // Checks that depend on the real input override the random plan.
  const nowWindow = Math.floor(Date.now() / WINDOW_MS);
  if (nowWindow - parsed.window > 1) {
    fails.code = 'That QR code has expired. The code changes every 30 seconds, so scan the instructor screen again.';
  }
  const enr = db.enrollments[user.id];
  if (!enr?.deviceId || enr.deviceId !== input.deviceId) fails.device = FAIL_NOTES.device;
  if (!input.coords) {
    fails.location = `Your location was not shared. ${input.geoError ?? 'Turn on Location for this site and try again.'}`;
  } else {
    const d = Math.round(distanceM(input.coords, session));
    if (d > session.radiusM + Math.min(input.coords.accuracy, 100)) {
      fails.location = `You appear to be about ${d} m from the classroom, outside the ${session.radiusM} m limit. Move into the classroom and try again.`;
    }
  }
  if (input.behaviour.elapsedMs < 2500) fails.behaviour = FAIL_NOTES.behaviour;

  const checkIn = makeCheckIn({
    session,
    studentId: user.id,
    name: user.fullName,
    enrolmentNo: user.enrolmentNo,
    at: Date.now(),
    fails,
    rnd,
    tweak: (l) => {
      if (input.behaviour.method === 'paste' && l.behaviour.passed) l.behaviour.score = Math.min(l.behaviour.score, 78);
    },
  });
  db.checkIns.push(checkIn);
  saveDb(db);
  return checkIn;
}

/* -------------------------------------------------------------- admin feed */

export async function listCheckIns(filter: DecisionFilter = 'ALL'): Promise<CheckIn[]> {
  await delay();
  const all = loadDb().checkIns.slice().sort((a, b) => b.at.localeCompare(a.at));
  return filter === 'ALL' ? all : all.filter((c) => c.decision === filter);
}

/**
 * Live feed. Calls onData with the full, newest-first list whenever it changes.
 * The real version can use SSE or a WebSocket. Returns an unsubscribe function.
 */
export function subscribeCheckIns(
  opts: { sessionId?: string },
  onData: (items: CheckIn[]) => void,
  onError?: (e: unknown) => void,
): () => void {
  let stopped = false;
  let lastSig = '';
  const emit = () => {
    if (stopped) return;
    try {
      const db = loadDb();
      if (maybeSimulate(db)) saveDb(db);
      const items = db.checkIns
        .filter((c) => !opts.sessionId || c.sessionId === opts.sessionId)
        .sort((a, b) => b.at.localeCompare(a.at));
      const sig = items.map((c) => `${c.id}:${c.decision}:${c.resolvedBy ?? ''}`).join('|');
      if (sig !== lastSig) {
        lastSig = sig;
        onData(items);
      }
    } catch (e) {
      onError?.(e);
    }
  };
  const first = setTimeout(emit, 600);
  const iv = setInterval(emit, 2500);
  return () => {
    stopped = true;
    clearTimeout(first);
    clearInterval(iv);
  };
}

export async function decideCheckIn(id: string, decision: 'APPROVED' | 'REJECTED'): Promise<CheckIn> {
  await delay(450);
  const admin = requireUser('admin');
  const db = loadDb();
  const c = db.checkIns.find((x) => x.id === id);
  if (!c) throw new ApiError('This check-in no longer exists.', 'Reload the list to see the latest check-ins.');
  if (c.decision !== 'REVIEW') {
    throw new ApiError('This check-in was already decided.', 'Reload the list to see the latest status.');
  }
  c.decision = decision;
  c.resolvedBy = admin.fullName;
  saveDb(db);
  return c;
}

const csvCell = (v: string | number) => {
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export async function exportCheckInsCsv(filter: DecisionFilter = 'ALL'): Promise<string> {
  await delay(300);
  requireUser('admin');
  const rows = loadDb()
    .checkIns.filter((c) => filter === 'ALL' || c.decision === filter)
    .sort((a, b) => b.at.localeCompare(a.at));
  const header = ['id', 'time', 'session', 'student', 'enrolment_no', 'decision', 'confidence', ...LAYER_KEYS.map((k) => `${k}_score`), 'reason', 'resolved_by'];
  const lines = rows.map((c) =>
    [c.id, c.at, c.sessionTitle, c.studentName, c.enrolmentNo, c.decision, c.confidence, ...LAYER_KEYS.map((k) => c.layers[k].score), c.reason, c.resolvedBy ?? '']
      .map(csvCell)
      .join(','),
  );
  return [header.join(','), ...lines].join('\r\n');
}
