import type { Coords } from './types';

export class GeoError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'GeoError';
  }
}

/** Reads the device location. Rejects with a GeoError whose message says how to fix the problem. */
export function getCoords(timeoutMs = 10000): Promise<Coords> {
  return new Promise((resolve, reject) => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      reject(new GeoError('This browser cannot share location. Use a recent browser and open the site over HTTPS.'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: Math.round(p.coords.accuracy) }),
      (err) => {
        if (err.code === err.PERMISSION_DENIED) {
          reject(new GeoError('Location is blocked for this site. Open your browser site settings, set Location to Allow, then try again.'));
        } else if (err.code === err.TIMEOUT) {
          reject(new GeoError('Finding your location took too long. Check that Location is on and try again near a window.'));
        } else {
          reject(new GeoError('Your device could not work out where it is. Turn on Location services and try again.'));
        }
      },
      { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 30000 },
    );
  });
}
